Step-by-step installation instructions can be found at: https://nitrox.rux.gg/wizard

For instructions on joining a server: https://nitrox.rux.gg/wiki/article/join-nitrox-subnautica-server

For instructions on hosting a server: https://nitrox.rux.gg/wiki/article/run-and-host-nitrox-subnautica-server

Find us on Discord:  https://discord.gg/Rf8n88c